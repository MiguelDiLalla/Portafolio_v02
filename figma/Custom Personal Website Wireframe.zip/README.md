
  # Custom Personal Website Wireframe

  This is a code bundle for Custom Personal Website Wireframe. The original project is available at https://www.figma.com/design/m6NcXZDYt2VYQodOs1ilZR/Custom-Personal-Website-Wireframe.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  